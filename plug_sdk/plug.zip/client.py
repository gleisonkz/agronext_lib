import asyncio
import json
import traceback

from plug_sdk.policy import (
    TransmissionData,
)
from plug_sdk.sdk import PlugSDK


async def test_submit_quotation(
    sdk: PlugSDK,
    valid_transmission_data,
):
    data = TransmissionData(**valid_transmission_data)
    return await sdk.submit_quotation(data)


async def test_get_proposal(
    sdk: PlugSDK,
    quotation_id,
):
    return await sdk.get_proposal(quotation_id)


async def test_reject_proposal(sdk: PlugSDK, proposal_id):
    return await sdk.reject_proposal(
        proposal_id=proposal_id,
        description="Motivo de teste",
        motive_code=1,
    )


async def test_issue_policy(
    sdk: PlugSDK,
    proposal_id,
):
    return await sdk.issue_policy(proposal_id)


async def test_generate_document(
    sdk: PlugSDK,
    proposal_id,
):
    return await sdk.generate_policy_document(proposal_id=proposal_id)


async def test_get_installments(
    sdk: PlugSDK,
    proposal_id,
):
    return await sdk.get_installments(proposal_id=proposal_id, installment=0)


async def test_get_boleto(sdk: PlugSDK, proposal_id, installment):
    return await sdk.get_boleto(proposal_id=proposal_id, installment=installment)


async def test_get_federal_subsidy_limit(sdk: PlugSDK, cpf_cnpj, year):
    return await sdk.get_federal_subsidy_limit(cpf_cnpj=cpf_cnpj, year=year)


async def test_cadin_lookup(sdk: PlugSDK, cpf_cnpj):
    return await sdk.cadin_lookup(cpf_cnpj=cpf_cnpj)


async def test_search_postal_code(sdk: PlugSDK, postal_code):
    return await sdk.search_postal_code(postal_code=postal_code)


async def test_search_address(sdk: PlugSDK, state, city, street):
    return await sdk.search_address(state=state, city=city, street=street)


async def test_verify_technical_restriction(sdk: PlugSDK, cpf_cnpj):
    return await sdk.verify_technical_restriction(cpf_cnpj=cpf_cnpj)


def capture_response_error(func):
    async def wrapper(*args, **kwargs):
        try:
            result = await func(*args, **kwargs)
            return result, None
        except Exception as e:
            traceback.print_exc()
            return None, f"{type(e).__name__}: {str(e)}"

    return wrapper


async def main():
    plug = PlugSDK(base_url="http://uatplug.essor.net/")

    with open("tests/fixtures/valid_transmission_data.json") as f:
        request_data = json.load(f)
        request_data["section_number"] = 2
        del request_data["secao"]
        request_data["numeroProposta"] = str(int(request_data["numeroProposta"]) + 10)

    with open("tests/fixtures/valid_transmission_response.json") as f:
        response_data = json.load(f)

    quotation_id = "17604470749248"  # request_data["numeroProposta"]
    proposal_id = int(response_data["idEndosso"])
    policy_id = "xpto"
    cpf_cnpj = "12345678909"
    year = 2025
    postal_code = "91760600"
    state = "RS"
    city = "Porto Alegre"
    street = "Ipiranga"
    installment = 1

    test_funcs = [
        {
            "name": "submit_quotation",
            "fn": test_submit_quotation,
            "params": {
                "sdk": plug,
                "valid_transmission_data": request_data,
            },
        },
        {
            "name": "get_proposal",
            "fn": test_get_proposal,
            "params": {"sdk": plug, "quotation_id": quotation_id},
        },
        {
            "name": "reject_proposal",
            "fn": test_reject_proposal,
            "params": {"sdk": plug, "proposal_id": proposal_id},
        },
        {
            "name": "issue_policy",
            "fn": test_issue_policy,
            "params": {
                "sdk": plug,
                "proposal_id": proposal_id,
            },
        },
        {
            "name": "generate_document",
            "fn": test_generate_document,
            "params": {"sdk": plug, "proposal_id": proposal_id},
        },
        {
            "name": "get_installments",
            "fn": test_get_installments,
            "params": {"sdk": plug, "proposal_id": proposal_id},
        },
        {
            "name": "get_boleto",
            "fn": test_get_boleto,
            "params": {"sdk": plug, "proposal_id": proposal_id, "installment": installment},
        },
        {
            "name": "get_federal_subsidy_limit",
            "fn": test_get_federal_subsidy_limit,
            "params": {"sdk": plug, "cpf_cnpj": cpf_cnpj, "year": year},
        },
        {
            "name": "cadin_lookup",
            "fn": test_cadin_lookup,
            "params": {"sdk": plug, "cpf_cnpj": cpf_cnpj},
        },
        {
            "name": "search_postal_code",
            "fn": test_search_postal_code,
            "params": {"sdk": plug, "postal_code": postal_code},
        },
        {
            "name": "search_address",
            "fn": test_search_address,
            "params": {"sdk": plug, "state": state, "city": city, "street": street},
        },
        {
            "name": "verify_technical_restriction",
            "fn": test_verify_technical_restriction,
            "params": {"sdk": plug, "cpf_cnpj": cpf_cnpj},
        },
    ]

    responses = {}
    errors = {}
    skip_list = [
        "submit_quotation",
        "get_proposal",
        "reject_proposal",
        "issue_policy",
        "generate_document",
        "get_installments",
        "get_boleto",
        "get_federal_subsidy_limit",
        "cadin_lookup",
        "search_postal_code",
        "search_address",
        "verify_technical_restriction",
    ]

    for test in test_funcs:
        name = test["name"]

        if name in skip_list:
            print(f"⚠️ Skipping {name}")
            continue

        fn = test["fn"]
        params = test["params"]

        wrapped_fn = capture_response_error(fn)
        response, error = await wrapped_fn(**params)

        if error:
            errors[name] = error
        else:
            try:
                responses[name] = json.loads(json.dumps(response, default=str))
            except Exception as dump_err:
                errors[name] = f"Response not serializable: {dump_err}"

    result = {"responses": responses, "errors": errors}

    with open("test_run_output.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print("✅ Done. Output saved to test_run_output.json")


if __name__ == "__main__":
    asyncio.run(main())
